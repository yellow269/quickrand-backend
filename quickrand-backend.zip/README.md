# QuickRand Backend
This is the backend scaffold.
